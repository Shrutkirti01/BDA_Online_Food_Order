import sys
import csv

reader = csv.DictReader(sys.stdin)

for row in reader:
    try:
        category = row["category"].strip()

        if category:
            print(f"{category}\t1")

    except:
        continue