import sys

current_category = None
count = 0

for line in sys.stdin:
    category, value = line.strip().split("\t")
    value = int(value)

    if current_category == category:
        count += value

    else:
        if current_category is not None:
            print(f"{current_category}\t{count}")

        current_category = category
        count = value

if current_category is not None:
    print(f"{current_category}\t{count}")